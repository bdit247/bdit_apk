﻿// ---------------------------------------------------------------------------- 
// Copyright (c) Microsoft Corporation. All rights reserved.
// ---------------------------------------------------------------------------- 

using System.Reflection;

[assembly: AssemblyTitle("Microsoft.Azure.Mobile.Server.Home")]