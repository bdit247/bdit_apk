﻿Imports Microsoft.Azure.Mobile.Server

Public Class TodoItem
    Inherits EntityData

    Public Property Text As String
    Public Property Complete As Boolean
End Class