﻿// ----------------------------------------------------------------------------
// Copyright (c) Microsoft Corporation. All rights reserved.
// ----------------------------------------------------------------------------

namespace ZumoE2EServerApp.DataObjects
{
    public class LoginUser
    {
        public string UserId;

        public string AuthenticationToken;
    }
}