﻿// ---------------------------------------------------------------------------- 
// Copyright (c) Microsoft Corporation. All rights reserved.
// ---------------------------------------------------------------------------- 

using System.Reflection;

namespace Microsoft.Azure.Mobile.Server.Mocks
{
    public class AssemblyMock : Assembly
    {
        public AssemblyMock()
        {
        }
    }
}
