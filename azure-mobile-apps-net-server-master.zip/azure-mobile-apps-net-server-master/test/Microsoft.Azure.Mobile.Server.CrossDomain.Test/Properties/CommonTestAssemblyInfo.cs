﻿// ---------------------------------------------------------------------------- 
// Copyright (c) Microsoft Corporation. All rights reserved.
// ---------------------------------------------------------------------------- 

using System;
using System.Reflection;
using System.Runtime.InteropServices;

// Common assembly information.
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("© Microsoft Corporation.  All rights reserved.")]
[assembly: AssemblyProduct("Microsoft® Azure Mobile Services Backend Test")]

[assembly: CLSCompliant(false)]
[assembly: ComVisible(false)]
[assembly: AssemblyConfiguration("")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]