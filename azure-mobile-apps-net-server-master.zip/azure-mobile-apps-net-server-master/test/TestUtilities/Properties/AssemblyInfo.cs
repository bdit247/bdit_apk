﻿// ---------------------------------------------------------------------------- 
// Copyright (c) Microsoft Corporation. All rights reserved.
// ---------------------------------------------------------------------------- 

using System.Reflection;

[assembly: AssemblyTitle("TestUtilities")]
[assembly: AssemblyDescription("")]
